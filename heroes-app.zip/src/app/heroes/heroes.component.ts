import { Component, OnDestroy, OnInit } from '@angular/core';
import { HEROES } from '../mock-heroes';
import { HeroService } from '../services/hero.service';
import { MessageService } from '../services/message.service';
import { Hero } from '../types/hero';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.scss']
})
export class heroesComponent implements OnInit {

  selectedHero?: Hero

  heroes: Hero[] = []

  constructor(public heroService: HeroService, private messagesService: MessageService) {
  }

  ngOnInit(): void {
    this.getHeroes()
  }

  getHeroes() {
    this.heroService.getHeroes()
      .subscribe(heros => this.heroes = heros)
  }

  onSelect(hero: Hero) {
    this.selectedHero = hero
    this.messagesService.add(`HeroesComponent: Heroe Seleccionado con id=${this.selectedHero.id}`)
  }

}
